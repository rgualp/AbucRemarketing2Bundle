<?php

namespace MyCp\mycpBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class mycpBundle extends Bundle
{
}

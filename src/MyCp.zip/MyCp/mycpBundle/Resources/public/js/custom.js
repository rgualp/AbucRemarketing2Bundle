$(function () {
    $('.tooltip_msg').tooltip();
});


<?php

namespace MyCp\mycpBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ownershipDescriptionLang
 *
 * @ORM\Table(name="ownershipdescriptionlang")
 * @ORM\Entity
 */
class ownershipDescriptionLang
{
    /**
     * @var integer
     *
     * @ORM\Column(name="odl_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $odl_id;

    /**
     * @ORM\ManyToOne(targetEntity="lang",inversedBy="langslang")
     * @ORM\JoinColumn(name="odl_id_lang",referencedColumnName="lang_id")
     */
    private $odl_id_lang;

    /**
     * @ORM\ManyToOne(targetEntity="ownership",inversedBy="ownershipDescriptionLang")
     * @ORM\JoinColumn(name="odl_id_ownership",referencedColumnName="own_id")
     */
    private $odl_ownership;

    /**
     * @var string
     *
     * @ORM\Column(name="odl_description", type="string", length=255)
     */
    private $odl_description;

    /**
     * @var string
     *
     * @ORM\Column(name="odl_brief_description", type="string", length=255)
     */
    private $odl_brief_description;



    /**
     * Get odl_id
     *
     * @return integer 
     */
    public function getOdlId()
    {
        return $this->odl_id;
    }

    /**
     * Set odl_description
     *
     * @param string $odlDescription
     * @return ownershipDescriptionLang
     */
    public function setOdlDescription($odlDescription)
    {
        $this->odl_description = $odlDescription;
    
        return $this;
    }

    /**
     * Get odl_description
     *
     * @return string 
     */
    public function getOdlDescription()
    {
        return $this->odl_description;
    }

    /**
     * Set odl_id_lang
     *
     * @param \MyCp\mycpBundle\Entity\lang $odlIdLang
     * @return ownershipDescriptionLang
     */
    public function setOdlIdLang(\MyCp\mycpBundle\Entity\lang $odlIdLang = null)
    {
        $this->odl_id_lang = $odlIdLang;
    
        return $this;
    }

    /**
     * Get odl_id_lang
     *
     * @return \MyCp\mycpBundle\Entity\lang 
     */
    public function getOdlIdLang()
    {
        return $this->odl_id_lang;
    }

    /**
     * Set odl_ownership
     *
     * @param \MyCp\mycpBundle\Entity\ownership $odlOwnership
     * @return ownershipDescriptionLang
     */
    public function setOdlOwnership(\MyCp\mycpBundle\Entity\ownership $odlOwnership = null)
    {
        $this->odl_ownership = $odlOwnership;
    
        return $this;
    }

    /**
     * Get odl_ownership
     *
     * @return \MyCp\mycpBundle\Entity\ownership 
     */
    public function getOdlOwnership()
    {
        return $this->odl_ownership;
    }

    /**
     * Set odl_brief_description
     *
     * @param string $odlBriefDescription
     * @return ownershipDescriptionLang
     */
    public function setOdlBriefDescription($odlBriefDescription)
    {
        $this->odl_brief_description = $odlBriefDescription;
    
        return $this;
    }

    /**
     * Get odl_brief_description
     *
     * @return string 
     */
    public function getOdlBriefDescription()
    {
        return $this->odl_brief_description;
    }

    /**
     * Codigo Yanet - Inicio
     */

    /**
     * Retur object as string
     * @return string
     */
    public function __toString()
    {
        return $this->getOdlDescription();
    }

    /**
     * Codigo Yanet - Fin
     */
}
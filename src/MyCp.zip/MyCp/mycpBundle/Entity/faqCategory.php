<?php

namespace MyCp\mycpBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * faqCategory
 *
 * @ORM\Table(name="faqcategory")
 * @ORM\Entity
 */
class faqCategory
{
    /**
     * @var integer
     *
     * @ORM\Column(name="faq_cat_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $faq_cat_id;

    /**
     * Get faq_cat_id
     *
     * @return integer 
     */
    public function getFaqCatId()
    {
        return $this->faq_cat_id;
    }
}
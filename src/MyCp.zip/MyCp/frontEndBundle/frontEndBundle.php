<?php

namespace MyCp\frontEndBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class frontEndBundle extends Bundle
{
}
